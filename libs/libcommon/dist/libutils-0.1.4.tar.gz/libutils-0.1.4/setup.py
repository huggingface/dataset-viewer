# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['libutils']

package_data = \
{'': ['*']}

install_requires = \
['function-parser>=0.0.3,<0.0.4',
 'orjson>=3.6.4,<4.0.0',
 'starlette>=0.16.0,<0.17.0']

setup_kwargs = {
    'name': 'libutils',
    'version': '0.1.4',
    'description': 'Library for utils',
    'long_description': None,
    'author': 'Sylvain Lesage',
    'author_email': 'sylvain.lesage@huggingface.co',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '==3.9.6',
}


setup(**setup_kwargs)
