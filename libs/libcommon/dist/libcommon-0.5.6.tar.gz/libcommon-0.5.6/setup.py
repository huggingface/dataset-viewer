# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['libcommon']

package_data = \
{'': ['*']}

install_requires = \
['appdirs>=1.4.4,<2.0.0',
 'environs>=9.5.0,<10.0.0',
 'huggingface-hub>=0.11.0,<0.12.0',
 'mongo-types==0.15.1',
 'mongoengine>=0.24.1,<0.25.0',
 'orjson>=3.6.4,<4.0.0',
 'psutil>=5.9.2,<6.0.0',
 'pymongo[srv]>=3.13.0,<4.0.0']

setup_kwargs = {
    'name': 'libcommon',
    'version': '0.5.6',
    'description': 'Library for utils, common to all the services and workers',
    'long_description': 'None',
    'author': 'Sylvain Lesage',
    'author_email': 'sylvain.lesage@huggingface.co',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '==3.9.15',
}


setup(**setup_kwargs)
