# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['libcache']

package_data = \
{'': ['*']}

install_requires = \
['appdirs>=1.4.4,<2.0.0',
 'mongo-types==0.15.1',
 'mongoengine>=0.24.1,<0.25.0',
 'pymongo[srv]>=3.12.3,<4.0.0']

setup_kwargs = {
    'name': 'libcache',
    'version': '0.2.2',
    'description': 'Library for the cache in mongodb',
    'long_description': None,
    'author': 'Sylvain Lesage',
    'author_email': 'sylvain.lesage@huggingface.co',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '==3.9.6',
}


setup(**setup_kwargs)
