# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['libqueue']

package_data = \
{'': ['*']}

install_requires = \
['environs>=9.5.0,<10.0.0',
 'mongo-types==0.15.1',
 'mongoengine>=0.24.1,<0.25.0',
 'psutil>=5.9.2,<6.0.0',
 'pymongo[srv]>=3.12.3,<4.0.0']

setup_kwargs = {
    'name': 'libqueue',
    'version': '0.4.1',
    'description': 'Library for the jobs queue in mongodb',
    'long_description': None,
    'author': 'Sylvain Lesage',
    'author_email': 'sylvain.lesage@huggingface.co',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '==3.9.6',
}


setup(**setup_kwargs)
