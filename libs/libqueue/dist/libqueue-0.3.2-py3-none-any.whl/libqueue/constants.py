# SPDX-License-Identifier: Apache-2.0
# Copyright 2022 The HuggingFace Authors.

DEFAULT_MAX_LOAD_PCT: int = 70
DEFAULT_MAX_MEMORY_PCT: int = 80
DEFAULT_WORKER_SLEEP_SECONDS: int = 15
